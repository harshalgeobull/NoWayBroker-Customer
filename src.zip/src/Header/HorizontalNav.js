import React, { useState, useEffect, useContext, useRef } from "react";
import { FiUser, FiMenu } from "react-icons/fi";
import { Link, useLocation } from "react-router-dom";
import { SearchContext } from "../containers/SearchContext";
import Login1 from "../auth/Login1";
import SignUp1 from "../auth/SignUp1";
import { useHistory } from "react-router-dom";
import { toast } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import axios from "axios";
import { IoCloseCircleOutline } from "react-icons/io5";

const HorizontalNav = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [isLoginModalOpen, setIsLoginModalOpen] = useState(false);
  const [isSignUpModalOpen, setIsSignUpModalOpen] = useState(false);
  const [isDropdownOpen, setIsDropdownOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const dropdownRef = useRef(null); // Reference to the dropdown menu
  const { propertyCity, setPropertyCity } = useContext(SearchContext);
  const { searchCity, setSearchCity } = useContext(SearchContext);
  const [inputValue, setInputValue] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [type, setType] = useState("");
  const [showModal, setShowModal] = useState(false);
  const location = useLocation();
  const history = useHistory();
  const isPropertyDashboard = location.pathname === "/property-dashboard";
  const [profileImage, setProfileImage] = useState("");

  const searchBarRoutes = [
    "/property",
    "/advisordashboard",
    "/searchdashboard",
    "/allproperties",
  ];

  const showSearchBar =
    [
      "/searchdashboard",
      "/property",
      "/advisordashboard",
      "/featuredDashboard",
      "/recommendedpropertiesDashboard",
    ].includes(location.pathname) ||
    location.pathname.startsWith("/citywiseproperties");

  const hideTabLinks = showSearchBar;

  useEffect(() => {
    if (!showSearchBar) {
      setSearchCity("");
      setInputValue("");
    }
  }, [location.pathname]);

  const checkLoginStatus = () => {
    const userId = sessionStorage.getItem("accessToken");
    setIsLoggedIn(!!userId);
  };

  useEffect(() => {
    checkLoginStatus();
    const intervalId = setInterval(checkLoginStatus, 1000);
    return () => clearInterval(intervalId);
  }, []);

  const handleLogout = () => {
    setShowModal(true); // open custom modal
  };

  const confirmLogout = () => {
    sessionStorage.clear();
    setShowModal(false);
    toast.success("Logout Successfully");
    setIsLoggedIn(false);
    history.push("/");
  };

  useEffect(() => {
    if (isDropdownOpen) {
      const timer = setTimeout(() => {
        setIsDropdownOpen(false);
      }, 3000);

      return () => clearTimeout(timer);
    }
  }, [isDropdownOpen]);

  const [freePostCount, setFreePostCount] = useState(0);
  const userId = sessionStorage.getItem("accessToken");
  const userType = sessionStorage.getItem("user_type");

  useEffect(() => {
    const checkPostLimits = async () => {
      try {
        const profileForm = new FormData();
        profileForm.append("user_id", userId);

        const profileResponse = await axios.post(
          `${process.env.REACT_APP_API_URL}/cust_api/get_profile`,
          profileForm,
          {
            headers: {
              "Content-Type": "multipart/form-data",
            },
          },
        );

        const countData = profileResponse?.data?.count_data;

        if (countData) {
          setFreePostCount(countData.free_post_count || 0);
        }
        setProfileImage(profileResponse?.data?.data?.profile_image || "");
      } catch (error) {
        console.error("Error checking post limits:", error);
      }
    };

    if (userId) {
      checkPostLimits();
    }
  }, [userId]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  // Prevent background scrolling when modal is open
  useEffect(() => {
    if (isLoginModalOpen || isSignUpModalOpen) {
      document.body.style.overflow = "hidden";
    } else {
      document.body.style.overflow = "auto";
    }
    // Cleanup when component unmounts
    return () => {
      document.body.style.overflow = "auto";
    };
  }, [isLoginModalOpen, isSignUpModalOpen]);

  return (
    <nav className="flex flex-wrap items-center justify-between px-4 py-3 text-sm font-light bg-white rounded-lg md:px-20">
      {/* Left side: Logo and Navigation Tabs */}
      <div className="flex items-center justify-between w-full md:w-auto">
        {/* Logo */}
        <Link to="/">
          <img
            src="/image/app.png"
            alt="NoWayBroker Logo"
            className="w-[95px] h-[90px]"
          />
        </Link>

        {/* Hamburger Menu for Mobile */}
        <button
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          className="md:hidden focus:outline-none"
        >
          <FiMenu className="text-2xl text-black" />
        </button>
      </div>

      {/* Navigation Tabs and Search Bar */}
      <div
        className={`${
          isMobileMenuOpen ? "block" : "hidden"
        } md:flex md:items-center md:space-x-7 w-full md:w-auto mt-4 md:mt-0`}
      >
        {/* Show Search Bar on specific pages */}
        {showSearchBar && (
          <div className="flex flex-col items-center justify-between w-full gap-4 mt-2 md:w-auto md:flex-row md:mt-0">
            <div className="flex items-center flex-wrap gap-2 my-border rounded-md px-3 py-2 w-full md:w-[500px] bg-white min-h-12">
              {searchCity && (
                <span className="flex items-center px-3 py-1 text-sm text-black bg-gray-200 rounded-full">
                  {searchCity}
                  <button
                    className="ml-2 text-black hover:text-gray-600 focus:outline-none"
                    onClick={() => setSearchCity("")}
                  >
                    ✕
                  </button>
                </span>
              )}

              {searchQuery && (
                <span className="flex items-center px-3 py-1 text-sm text-black bg-gray-200 rounded-full">
                  {searchQuery}
                  <button
                    className="ml-2 text-black hover:text-gray-600 focus:outline-none"
                    onClick={() => setSearchQuery("")}
                  >
                    ✕
                  </button>
                </span>
              )}

              <input
                type="text"
                className="bg-transparent border-none outline-none"
                placeholder="Search Location..."
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" && inputValue.trim() !== "") {
                    setSearchCity(inputValue.trim());
                    setInputValue("");
                  }
                }}
              />
            </div>
          </div>
        )}

        {!hideTabLinks && (
          <ul className="flex flex-col items-center w-full space-y-4 md:flex-row md:space-y-0 md:space-x-10 md:w-auto">
            <li>
              <Link
                to={{ pathname: "/property", state: { propertyType: "Buy" } }}
                className="text-lg font-medium tracking-wider text-gray-600 no-underline transition hover:my-text hover:no-underline"
              >
                For Buyers
              </Link>
            </li>
            <li>
              <Link
                to={{
                  pathname: "/property",
                  state: { propertyType: "Rent" },
                }}
                className="text-lg font-medium tracking-wider text-gray-600 no-underline transition hover:my-text hover:no-underline"
              >
                For Tenants
              </Link>
            </li>
            <li>
              <Link
                to={`/advisordashboard?label=Owner`}
                className="text-lg font-medium tracking-wider text-gray-600 no-underline transition hover:my-text hover:no-underline"
              >
                For Owners
              </Link>
            </li>
            <li>
              <Link
                to={`/advisordashboard?label=Builder`}
                className="text-lg font-medium tracking-wider text-gray-600 no-underline transition hover:my-text hover:no-underline"
              >
                For Dealers / Builders
              </Link>
            </li>
          </ul>
        )}
      </div>

      {/* Right side: Download App, Post Property, and Profile/Login */}
      <div
        className={`${
          isMobileMenuOpen ? "block" : "hidden"
        } md:flex md:items-center md:space-x-6 w-full md:w-auto mt-4 md:mt-0`}
      >
        {/* Buttons Group */}
        <div className="flex flex-col items-center space-y-4 md:flex-row md:space-x-4 md:space-y-0">
          <Link
            to="/download"
            className="px-4 py-2 text-base font-medium my-text no-underline border border-rose-500 rounded hover:text-rose-700 hover:no-underline"
          >
            Download Mobile App
          </Link>

          {isLoggedIn ? (
            <Link
              to="/add_new_property"
              className="px-4 py-2 text-base font-medium text-center text-white no-underline my-bg border border-gray-300 rounded hover:my-bg hover:no-underline"
            >
              Post Property{" "}
              {freePostCount > 0 && (
                <span className="px-2 py-0 ml-2 text-sm text-black bg-green-500 rounded-full">
                  FREE
                </span>
              )}
            </Link>
          ) : (
            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="px-4 py-2 text-base font-medium text-center text-white my-bg border border-gray-300 rounded hover:my-bg hover:no-underline"
            >
              Post Property{" "}
              <span className="px-2 py-0 ml-2 text-sm text-black bg-green-500 rounded-full">
                FREE
              </span>
            </button>
          )}

          {isLoggedIn && userType !== "Owner" && (
            <Link
              to="/add_new_project"
              className="no-underline hover:no-underline"
            >
              <button className="px-4 py-2 text-base font-medium text-center text-white my-bg border border-gray-300 rounded hover:my-bg">
                Post Project
              </button>
            </Link>
          )}
        </div>
        <div className="relative ">
          {isLoggedIn ? (
            <button
              onClick={() => setIsDropdownOpen(!isDropdownOpen)}
              className="focus:outline-none"
            >
              {profileImage &&
              profileImage !== "null" &&
              profileImage.trim() !== "" ? (
                <img
                  src={profileImage}
                  alt="Profile"
                  className="object-cover w-10 h-10 border border-gray-300 rounded-full"
                />
              ) : (
                <FiUser
                  className="p-2 text-black bg-gray-100 rounded-full"
                  style={{ fontSize: "40px" }}
                />
              )}
            </button>
          ) : (
            <button
              onClick={() => setIsLoginModalOpen(true)}
              className="focus:outline-none"
            >
              <FiUser
                className="p-2 text-black bg-gray-100 rounded-full"
                style={{ fontSize: "40px" }}
              />
            </button>
          )}

          {isDropdownOpen && isLoggedIn && (
            <div className="absolute right-0 z-50 mt-2 bg-white border border-gray-200 rounded-md shadow-lg w-44">
              <ul className="py-2 pl-0">
                <li>
                  <Link
                    to={{
                      pathname: "/dashboard",
                      state: { page: "profile" },
                    }}
                    className="block px-4 py-2 text-gray-800 no-underline hover:bg-gray-100 hover:no-underline"
                  >
                    Profile
                  </Link>
                </li>
                <li>
                  <Link
                    to={{
                      pathname: "/dashboard",
                      state: { page: "myProperties" },
                    }}
                    className="block px-4 py-2 text-gray-800 no-underline hover:bg-gray-100 hover:no-underline"
                  >
                    My Properties
                  </Link>
                </li>
                <li>
                  <Link
                    to={{
                      pathname: "/dashboard",
                      state: { page: "myVirtualtour" },
                    }}
                    className="block px-4 py-2 text-gray-800 no-underline hover:bg-gray-100 hover:no-underline"
                  >
                    My Virtual Tour
                  </Link>
                </li>
                <li>
                  <Link
                    to={{
                      pathname: "/dashboard",
                      state: { page: "myFavourite" },
                    }}
                    className="block px-4 py-2 text-gray-800 no-underline hover:bg-gray-100 hover:no-underline"
                  >
                    My Favourites
                  </Link>
                </li>
                <li>
                  <Link
                    to={{
                      pathname: "/dashboard",
                      state: { page: "saveSerches" },
                    }}
                    className="block px-4 py-2 text-gray-800 no-underline hover:bg-gray-100 hover:no-underline"
                  >
                    Saved Serches
                  </Link>
                </li>
                <li>
                  <button
                    onClick={handleLogout}
                    className="w-full px-4 py-2 text-left text-gray-800 no-underline hover:bg-gray-100 hover:no-underline"
                  >
                    Logout
                  </button>
                </li>
              </ul>
            </div>
          )}
        </div>
      </div>

      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50">
          <div className="relative p-6 text-center bg-white shadow-lg rounded-2xl w-96">
            {/* Close (X) Icon */}
            <button
              className="absolute text-2xl text-black top-2 right-2"
              onClick={() => setShowModal(false)}
            >
              <IoCloseCircleOutline />
            </button>

            <h2 className="text-2xl font-semibold">Are you sure?</h2>
            <p className="mt-2 text-gray-500">You will be logged out!</p>

            <div className="flex justify-center gap-6 mt-4">
              <button
                className="px-8 py-2 text-white my-bg rounded-md hover:my-bg"
                onClick={confirmLogout}
              >
                Yes, logout!
              </button>
              <button
                className="px-8 py-2 text-black bg-white border border-black rounded-md hover:bg-gray-100"
                onClick={() => setShowModal(false)}
              >
                Cancel
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Modals */}
      <Login1
        isOpen={isLoginModalOpen}
        onClose={() => setIsLoginModalOpen(false)}
        onSwitchToSignUp={() => {
          setIsLoginModalOpen(false);
          setIsSignUpModalOpen(true);
        }}
      />

      <SignUp1
        isOpen={isSignUpModalOpen}
        onClose={() => setIsSignUpModalOpen(false)}
        onSwitchToLogin={() => {
          setIsSignUpModalOpen(false);
          setIsLoginModalOpen(true);
        }}
      />
    </nav>
  );
};

export default HorizontalNav;
